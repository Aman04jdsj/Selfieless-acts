<?php
   $password="";
   $host="localhost";
   $dbname="intmgt1";
   $un="root";
   $db_cn=mysqli_connect($host,$un,$password,$dbname) or die("cannot connect");
  
?>